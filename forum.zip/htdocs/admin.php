<?php
if (! is_file("head.php")) { } else { include "head.php"; }
?>
<?
if (isset($_GET['deltopic']))
  {
$topic = $_GET['topic'];
@unlink("topics/$topic.txt");
}
?>
<?
if (isset($_GET['closetopic']))
  {
$topic = $_GET['topic'];
$dir = "topics/$topic.txt";
chmod("$dir", 0400);
}
if (isset($_GET['opentopic']))
  {
$topic = $_GET['topic'];
$dir = "topics/$topic.txt";
chmod("$dir", 0666);
}
?>
<?
if (isset($_GET['delpost']))
  {
$topic = $_GET['topic'];
$number = $_GET['number'];
$arr = file("topics/$topic.txt");

$content = "";
$needle = $number;
$replace = '|უცნობი|00:00:00 weekday 00.00.0000|[color=red]აღნიშნული გამოხმაურება წაშლილია[/color]||000.000.000.00|';
error_reporting(0);
foreach($arr as $key => $line) {
    if($line[0] == $needle) {
        $arr[$key] = $needle . "$replace" . PHP_EOL;
    }
    $content .= $arr[$key];
}
file_put_contents("topics/$topic.txt", $content);
}
?>
<?

$ip = $_POST['ip'];

if (isset($_GET['ipsoft']))
  { 
error_reporting(0);
$ban = file("ban/ip.txt");
$text1 = "$ip|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$fp=fopen("ban/ip.txt","a");
fputs($fp,"$text1\r\n");
fclose($fp);
}
?>
<?
if (isset($_GET['clear']))
  {

@unlink("ban/ip.txt");

}
?>
<?php
$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == "admin"
&& $pass == "12345678")
{
print "<table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'><big>თემის წაშლა</big></th></tr></table>
<form method=GET action=admin.php><input type=hidden name=deltopic value=delete><table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'>წასაშლელი თემის არჩევის ID</th></tr><td align='center'><input type=number size=10 name=topic required><button>წაშლა</button></form></td></tr></table>";
print "<table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'><big>თემის დახურვა</big></th></tr></table>
<form method=GET action=admin.php><input type=hidden name=closetopic value=delete><table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'>დასახური თემის არჩევის ID</th></tr><td align='center'><input type=number size=10 name=topic required><button>დახურვა</button></form></td></tr></table>";
print "<table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'><big>თემის გაღება</big></th></tr></table>
<form method=GET action=admin.php><input type=hidden name=opentopic value=delete><table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'>გასაღები თემის არჩევის ID</th></tr><td align='center'><input type=number size=10 name=topic required><button>გაღება</button></form></td></tr></table>";
print "<table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'><big>გამოხმაურების წაშლა</big></th></tr></table>
<form method=GET action=admin.php><input type=hidden name=delpost value=delete><table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='right'><small>თემის არჩევის ID</small></th><th align='left'><small># გამოხმაურება ID</small></th></tr><td align='right'><input type=number size=10 name=topic required></td><td align='left'><input type=number size=10 name=number required></td></tr></table><table align='center' border='1' style='width:100%;height:auto;'>
<tr><td align='center'><button>გამოხმაურების წაშლა</button></form></td></tr></table>";
print "<table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'><big>მომხმარებლის დაბლოკვა</big></th></tr></table>
<form method=POST action=admin.php?ipsoft><table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'>მომხმარებლის IP მისამართი</th></tr><td align='center'><input type=text name=ip required><button>დაბლოკვა</button></form></td></tr><form method=POST action=admin.php?clear><table align='center' border='1' style='width:100%;height:auto;'>
<tr><td align='center'><button>დაბლოკილი IP მისამართების წაშლა</button></form></td></tr></table>";
}
else
{
    if(isset($_POST))
    {?>
    <script src="jquery.min.js"></script>
<script>
            $(function() {
 
                if (localStorage.checkbox && localStorage.checkbox != '') {
                    $('#remember').attr('checked', 'checked');
                    $('#user').val(localStorage.user);
                    $('#pass').val(localStorage.pass);
                } else {
                    $('#remember').removeAttr('checked');
                    $('#user').val('');
                    $('#pass').val('');
                }
 
                $('#remember').click(function() {
 
                    if ($('#remember').is(':checked')) {
                        localStorage.user = $('#user').val();
                        localStorage.pass = $('#pass').val();
                        localStorage.checkbox = $('#remember').val();
                    } else {
                        localStorage.user = '';
                        localStorage.pass = '';
                        localStorage.checkbox = '';
                    }
                });
            });
 
        </script>
<table align="center" border="1" style="width:100%;height:auto;">
<tr><th align="center">ავტორიზაცია</th></tr></table><table align="center" border="1" style="width:100%;height:auto;"><form method="POST" action="admin.php">
<tr><th align="center"><img style='text-align: center;' src='img/user.svg'> სახელი</th><th><img style='text-align: center;' src='img/pass.svg'> პაროლი</th></tr><tr><td><input type="text" style="width: 100%;" id='user' name="user"></input><td><input type="password" style="width: 100%;" id='pass' name="pass"></input></td></tr></table><table align="center" border="1" style="width:100%;height:auto;">
<tr><td>
<label class="link" style="color: #333333; border-radius: 20px 20px 20px 20px;" for="remember"><input type="checkbox" id='remember'> დამახსოვრება</label>
</td></tr></table><table align="center" border="1" style="width:100%;height:auto;">
<td align="center"><input type="submit" style="width: 100%;" name="submit" value="შესვლა"></input></form></td></tr></table>
    <?}
}
?>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
