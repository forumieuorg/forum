<table align="center" border="1" style="width:100%;height:auto;">
<tr><td align="left"><font style="color:gray;"><small>&copy; 2024</small></font><a href="admin.php"><img src="img/admin.svg"></a></td></tr></table>
</body>
</html>

