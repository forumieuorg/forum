<?php

@session_start();
date_default_timezone_set("Asia/Tbilisi"); 

$path='online/';
$file_name=''.$ip = isset($_SERVER['HTTP_CLIENT_IP']) 
    ? $_SERVER['HTTP_CLIENT_IP'] 
    : isset($_SERVER['HTTP_X_FORWARDED_FOR']) 
      ? $_SERVER['HTTP_X_FORWARDED_FOR'] 
      : $_SERVER['REMOTE_ADDR'];
$file=$path.$file_name;
$atime=300;

function inc_count($path,$file,$atime)
{
    !is_dir($path)?mkdir($path,0755,true):false;
    !file_exists($file)?fopen($file, "w"):false;
    $time=file_get_contents($file);
    empty($time)?file_put_contents($file, (time()+$atime)):false;
    if($time<=time())
    {
    file_put_contents($file, time()+$atime);
    }
    if ($handle = opendir($path))
    {
	while (false !== ($entry = readdir($handle)))
	{
	    if ($entry != "." && $entry != "..")
	    {
		$time=file_get_contents($path.$entry);
		if($time<=time())
		{
		unlink($path.$entry);
		}
	    }
	}
	closedir($handle);
	$prefix = ((count(scandir($path))-2) == 1) ? 'მხოლოდ თქვენ' : 'თქვენი ჩათვლით';
	return '<table align="center" border="1" style="width:100%;height:auto;"><tr><th align="center">საიტზეა<span id="blink"><blink><font color=green><b><a class="link" href="index.php?x=online">'.(count(scandir($path))-2).'</a></b></font></blink></span>ადამიანი <font style="color:gray;"><small>' . $prefix . '. ბოლო '.($atime / 60).' წუთში</font></small></th></tr></table>';
    }
}

echo inc_count($path,$file,$atime);
?>
<table align="center" border="1" style="width:100%;height:auto;">
<tr><td align="left"><font style="color:gray;"><small>&copy; 2024</small></font><a href="admin.php"><img src="img/admin.svg"></a></td></tr></table>
<?php include 'stat.php'; ?>
</body>
</html>

