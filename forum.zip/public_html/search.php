<?php
if (! is_file("head.php")) { } else { include "head.php"; }

error_reporting(0);
$data1 = file("ban/ip.txt");
$data1size = sizeof($data1);
$n = "0";
    do {
    $datatext = explode("|", $data1[$n]);
if ($n == "0") { } else { }
$disallowed = array("$datatext[0]");
$ip = $_SERVER['REMOTE_ADDR']; 

if(in_array($ip, $disallowed)) {
echo "<script>window.location.href='index.php?x=suspended';</script>";
 exit;
}
$n++; } while($n < $data1size);
?>
<table align="center" border="1" style="width:100%;height:auto;">
<tr><th align="center"><big>საძიებო</big></th><tr></table><table align="center" border="1" style="width:100%;height:auto;"><tr><th align="center">

<form name="jksearch" action="search.php" method="get" onSubmit="jksitesearch(this)">

<input id="hiddenquery" type="hidden" name="keyword" /><input type="hidden" name="x" value="read"/> <input type="text" name="find" required> <input type="submit" value="ძებნა"></th></tr><tr>
 <td style='margin: 1px 1px 1px 1px; border-radius: 20px 20px 20px 20px; display: inline-block; word-break: break-all;' align="left"><input name="search" type="radio" checked> საძიებო სიტყვები <input name="search" type="radio"> თემის ID</td>

<script type="text/javascript">

var searchaction=[
"search.php",
"index.php?x=read"
]

var queryfieldname=["keyword","topic"]

function switchaction(cur, index){
cur.form.action=searchaction[index]
document.getElementById("hiddenquery").name=queryfieldname[index]
}

function jksitesearch(curobj){
for (i=0; i< document.jksearch.search.length; i++){
if (document.jksearch.search[i].checked==true)
switchaction(document.jksearch.search[i], i)
} 
document.getElementById("hiddenquery").value=""+curobj.find.value
}
</script>

</form>

</tr></table>
<?php
$find = $_GET['find'];
if ($find != "") {
    print '<table align="center" border="1" style="width:100%; height:auto;">';
  print "<tr><th align='left'>ძებნის შედეგი</th></tr></table>\r\n";
  }
if (isset($_GET["keyword"])){
   foreach(glob('topics/*.txt') as $file) { 
      $searchfor = $_GET["keyword"];
      $contents = file_get_contents($file);
      $pattern = preg_quote($searchfor, '/');
      $pattern = "/^.*$pattern.*\$/m";
      $a = $file;
      $id = strtr($a, array("topics/"=>"", ".txt"=>""));
      if(preg_match_all($pattern, $contents, $matches)){
         echo "<a href='index.php?x=read&topic=$id'><table align='center' border='1' style='width:100%; height:auto; word-break: break-all; text-decoration:none; display: inline-block;'>
<tr><td align='left'>\n";
         echo "\n";
         echo implode("<br>\n", $matches[0]);
         echo "\n\n</td></tr></table></a><br>";
      }
      else{
      }
   }
}
?>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
