<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, name-scalable=no">
<Title>ფორუმი</Title>
<meta name="description" content="ქართული ფორუმი">
<style>
    fieldset {
    border: 1px solid #d1d1d1;
    border-radius: 15px 15px 15px 15px;
    }
    table {
      letter-spacing: 1px;
      font-size: 0.9rem;
      border: 1px solid #f1f1fc;
      border-collapse: separate;
      border-spacing: 0;
    }

    td {
  border: solid 1px #fcfcfc;
  border-style: none solid solid none;
  padding: 10px;
    }
    th {
    background-color: #f1f1fc;
    border: 1px solid #f1f1fc;
      padding: 10px 20px;
    }
tr:first-child td:first-child { border-top-left-radius: 10px; }
tr:first-child td:last-child { border-top-right-radius: 10px; }

tr:last-child td:first-child { border-bottom-left-radius: 10px; }
tr:last-child td:last-child { border-bottom-right-radius: 10px; }

tr:first-child td { border-top-style: solid; }
tr td:first-child { border-left-style: solid; }
input[type=text] {
  background-color: #efefef;
  border-radius: 5px 5px 5px 5px;
  color: black;
  border: 1px solid gray;
  padding: 5px 5px;
}
input[type=password] {
  background-color: #efefef;
  border-radius: 5px 5px 5px 5px;
  color: black;
  border: 1px solid gray;
  padding: 5px 5px;
}
input[type=number] {
  background-color: #efefef;
  border-radius: 5px 5px 5px 5px;
  color: black;
  border: 1px solid gray;
  padding: 5px 5px;
}
textarea {
  background-color: #efefef;
  border-radius: 5px 5px 5px 5px;
  color: black;
  border: 1px solid gray;
  padding: 5px 5px;
}
input[type=submit] {
box-shadow: 1px 1px 1px 1px #dddddd;
  background-color: #eeeeee;
  border-radius: 15px 15px 15px 15px;
  color: black;
  border: 1px solid #bbbbbb;
  padding: 5px 5px;
}

button {
box-shadow: 1px 1px 1px 1px #dddddd;
  background-color: #eeeeee;
  border-radius: 15px 15px 15px 15px;
  color: black;
  border: 1px solid #bbbbbb;
  padding: 5px 5px;margin: 5px 5px;
}
a:hover {
display: inline-block;
  background-color: #dddddd;
  color: black;
  border: 1px solid #bbbbbb;
  text-decoration:none;
}
a {
display: inline-block;
box-shadow: 1px 1px 1px 1px #dddddd;
  background-color: #eeeeee;
  border-radius: 5px 5px 5px 5px;
  color: black;
  border: 1px solid #bbbbbb;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
.input { max-width: 100px; width: 100%; }
.username {
display: inline-block;
box-shadow: 0px 0px 0px 0px #dddddd;
  background-color: #eeeeee;
  border-radius: 0px 0px 0px 0px;
  color: black;
  border: 0px solid #bbbbbb;
  text-decoration:none;
  padding: 0px 0px 0px 0px;
  margin: 0px 0px 0px 0px;
}
.link {
display: inline-block;
box-shadow: 1px 1px 1px 1px #dddddd;
  background-color: #eeeeee;
  border-radius: 15px 15px 15px 15px;
  color: black;
  border: 1px solid #bbbbbb;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
 #blink {
                font-size: 15px;
                font-weight: bold;
                color: green;
                transition: 0.5s;
            }
blink, .blink {
    -webkit-animation: blink 1s step-end infinite;
    -moz-animation: blink 1s step-end infinite;
    -o-animation: blink 1s step-end infinite;
    animation: blink 1s step-end infinite;
}
@-webkit-keyframes blink { 67% { opacity: 0 }}
@-moz-keyframes blink {  67% { opacity: 0 }}
@-o-keyframes blink {  67% { opacity: 0 }}
@keyframes blink {  67% { opacity: 0 }}
</style>
    <script src="jquery.min.js"></script>
<script>
            $(function() {
 
                if (localStorage.auth && localStorage.auth != '') {
                    $('#login').attr('checked', 'checked');
                    $('#name').val(localStorage.name);
                    $('#email').val(localStorage.email);
                } else {
                    $('#login').removeAttr('checked');
                    $('#name').val('');
                    $('#email').val('');
                }
 
                $('#login').click(function() {
 
                    if ($('#login').is(':checked')) {
                        localStorage.name = $('#name').val();
                        localStorage.email = $('#email').val();
                        localStorage.auth = $('#login').val();
                    } else {
                        localStorage.name = '';
                        localStorage.email = '';
                        localStorage.auth = '';
                    }
                });
            });
 
        </script>
</head>
<body lang=ka>
<table align="center" border="1" style="width:100%;height:auto;">
<tr><td align="left"><a class='link' href='/index.php'><img style='text-align: center;' src='img/home.svg'> ფორუმი</a></td> <td align="center"><a class='link' href='/index.php?x=messages'><img style='text-align: center;' src='img/talk.svg'> საუბრები</a></td> <td align="right"><a class='link' href='/search.php'><img style='text-align: center;' src='img/search.svg'> ძებნა</a></td></tr></table>
