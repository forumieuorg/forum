<!-- TOP.GE ASYNC COUNTER CODE -->
<div id="top-ge-counter-container" data-site-id="117672"></div>
<script async src="//counter.top.ge/counter.js"></script>
<!-- / END OF TOP.GE COUNTER CODE -->
<!--LiveInternet counter--><a href="https://www.liveinternet.ru/click"
target="_blank"><img id="licnt207A" width="88" height="15" style="border:0" 
title="LiveInternet: number of visitors for today is shown"
src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAIBTAA7"
alt=""/></a><script>(function(d,s){d.getElementById("licnt207A").src=
"https://counter.yadro.ru/hit?t26.6;r"+escape(d.referrer)+
((typeof(s)=="undefined")?"":";s"+s.width+"*"+s.height+"*"+
(s.colorDepth?s.colorDepth:s.pixelDepth))+";u"+escape(d.URL)+
";h"+escape(d.title.substring(0,150))+";"+Math.random()})
(document,screen)</script><!--/LiveInternet-->
