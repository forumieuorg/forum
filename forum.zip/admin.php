<?php
if (! is_file("head.php")) { } else { include "head.php"; }
?>
<?

$topic = $_POST['topic'];
@unlink("topics/$topic.txt");

?>
<?

$ip = $_POST['ip'];

if (isset($_GET['ipsoft']))
  { 
error_reporting(0);
$ban = file("ban/ip.txt");
$text1 = "$ip|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$fp=fopen("ban/ip.txt","a");
fputs($fp,"$text1\r\n");
fclose($fp);
}
?>
<?
if (isset($_GET['clear']))
  {

@unlink("ban/ip.txt");

}
?>
<?php
$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == "admin"
&& $pass == "12345678")
{
print "<table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'><big>თემის წაშლა</big></th></tr></table>
<form method=POST><table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'>თემის არჩევის ID</th></tr><td align='center'><input type=number size=10 name=topic required><button>წაშლა</button></form></td></tr></table>";

print "<table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'><big>მომხმარებლის დაბლოკვა</big></th></tr></table>
<form method=POST action=admin.php?ipsoft><table align='center' border='1' style='width:100%;height:auto;'>
<tr><th align='center'>მომხმარებლის IP მისამართი</th></tr><td align='center'><input type=text name=ip required><button>დაბლოკვა</button></form></td></tr><form method=POST action=admin.php?clear><table align='center' border='1' style='width:100%;height:auto;'>
<tr><td align='center'><button>დაბლოკილი IP მისამართების წაშლა</button></form></td></tr></table>";
}
else
{
    if(isset($_POST))
    {?>
    <script src="jquery.min.js"></script>
<script>
            $(function() {
 
                if (localStorage.checkbox && localStorage.checkbox != '') {
                    $('#remember').attr('checked', 'checked');
                    $('#user').val(localStorage.user);
                    $('#pass').val(localStorage.pass);
                } else {
                    $('#remember').removeAttr('checked');
                    $('#user').val('');
                    $('#pass').val('');
                }
 
                $('#remember').click(function() {
 
                    if ($('#remember').is(':checked')) {
                        localStorage.user = $('#user').val();
                        localStorage.pass = $('#pass').val();
                        localStorage.checkbox = $('#remember').val();
                    } else {
                        localStorage.user = '';
                        localStorage.pass = '';
                        localStorage.checkbox = '';
                    }
                });
            });
 
        </script>
<table align="center" border="1" style="width:100%;height:auto;">
<tr><th align="center">ავტორიზაცია</th></tr></table><table align="center" border="1" style="width:100%;height:auto;"><form method="POST" action="admin.php">
<tr><th align="center"><img style='text-align: center;' src='img/user.svg'> სახელი</th><th><img style='text-align: center;' src='img/pass.svg'> პაროლი</th></tr><tr><td><input type="text" style="width: 100%;" id='user' name="user"></input><td><input type="password" style="width: 100%;" id='pass' name="pass"></input></td></tr></table><table align="center" border="1" style="width:100%;height:auto;">
<tr><td>
<label class="link" style="color: #333333; border-radius: 20px 20px 20px 20px;" for="remember"><input type="checkbox" id='remember'> დამახსოვრება</label>
</td></tr></table><table align="center" border="1" style="width:100%;height:auto;">
<td align="center"><input type="submit" style="width: 100%;" name="submit" value="შესვლა"></input></form></td></tr></table>
    <?}
}
?>
<?php
if (! is_file("bottom.php")) { } else { include "bottom.php"; }
?>
